package bgu.spl.mics.application.passiveObjects;

import org.junit.*;
import org.junit.runners.MethodSorters;

import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class InventoryTest {

    public static Inventory inventory;

    @BeforeClass
    public static void setUp() {
        inventory = Inventory.getInstance();
    }

    @Test
    public void AgetInstance() {
        assertNotEquals(inventory, null);

        Inventory inventory2 = inventory.getInstance();
        assertEquals(inventory2, inventory);
    }

    @Test
    public void Bload() {
        BookInventoryInfo[] books = new BookInventoryInfo[2];
        books[0] = new BookInventoryInfo("The Kite Runner", 5,50);
        books[1] = new BookInventoryInfo("The Witcher", 0, 10);
        inventory.load(books);

        assertEquals(50, inventory.checkAvailabiltyAndGetPrice("The Kite Runner"));
    }

    @Test
    public void Ctake() {
        assertEquals(OrderResult.SUCCESSFULLY_TAKEN, inventory.take("The Kite Runner"));
        assertEquals(OrderResult.NOT_IN_STOCK, inventory.take("The Witcher"));
        assertEquals(OrderResult.NOT_IN_STOCK, inventory.take("Room"));
    }

    @Test
    public void DcheckAvailabiltyAndGetPrice() {
        assertEquals(50, inventory.checkAvailabiltyAndGetPrice("The Kite Runner"));
        assertEquals(-1, inventory.checkAvailabiltyAndGetPrice("The Witcher"));
        assertEquals(-1, inventory.checkAvailabiltyAndGetPrice("Room"));
    }

    @Test
    public void EprintInventoryToFile() {
        inventory.printInventoryToFile("InventoryTest");
    }

}