package bgu.spl.mics.application.passiveObjects;

import bgu.spl.mics.application.services.SellingService;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MoneyRegisterTest {

    private static MoneyRegister register;
    private Customer c = new Customer("Simo", 0, "Bash", 3, 15, 33);

    @BeforeClass
    public static void setUp(){
        register = register.getInstance();
    }
    @Test
    public void AgetInstance() {
        System.out.println("getInstance");
        assertNotEquals(register, null);
        MoneyRegister register2 = register.getInstance();
        assertEquals(register, register2);
    }

//    @Test
//    public void Bfile() {
//        System.out.println("file");
//        BookInventoryInfo book1 = new BookInventoryInfo("The Witcher", 5, 50);
//        BookInventoryInfo book2 = new BookInventoryInfo("The Kite Runner", 3, 100);
//        OrderReceipt receipt = new OrderReceipt(0, "selling service", c, book1.getBookTitle(), book1.getPrice(), );
//        register.file(receipt);
//        OrderReceipt anotherReceipt = new OrderReceipt(1, c, book2.getBookTitle(), book1.getPrice(),"selling service");
//        register.file(anotherReceipt);
//    }

    @Test
    public void CgetTotalEarnings() {
        System.out.println("getTotalEarnings");
        assertEquals(150, register.getTotalEarnings());
    }

    @Test
    public void DchargeCreditCard() {
        System.out.println("chargeCreditCard");
        register.chargeCreditCard(c, 10);
        assertEquals(5, c.getAvailableCreditAmount());
        register.chargeCreditCard(c, 10);
        assertEquals(5, c.getAvailableCreditAmount());
    }

    @Test
    public void EprintOrderReceipts() {
        System.out.println("printOrderReceipts");
        register.printOrderReceipts("tryFile");
        try {
            FileInputStream inputStream = new FileInputStream(("tryFile"));
            ObjectInputStream ois = new ObjectInputStream(inputStream);
            System.out.println(ois.readObject().toString());
            ois.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}