package bgu.spl.mics.application.messages;

import bgu.spl.mics.Broadcast;
       // Sent by TimerService when duration ends, received by all services
public class TerminateAllBroadcast implements Broadcast {
}
