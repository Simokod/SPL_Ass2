package bgu.spl.mics;

import org.junit.Before;
import org.junit.Test;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class FutureTest {
    Future f=null;

    @Test
    public void get() {
        //  assertEquals(null, f.get());
        f.resolve(7);
        assertEquals(7,f.get());
    }

    @Test
    public void resolve() {
        f.resolve(7);
        assertEquals(7,f.get());
    }
    @Test
    public void isDone(){
        assertEquals(false,f.isDone());
        f.resolve(7);
        assertEquals(true,f.isDone());
    }

    @Test
    public void get1() {
        int timeout=1000;
        assertEquals(null, f.get(timeout, TimeUnit.MICROSECONDS.MILLISECONDS));
        long start=System.currentTimeMillis();
        f.resolve(0);
        boolean b= (System.currentTimeMillis()-start)<1000;
        assertEquals(true, b);
        assertEquals (0, f.get(timeout, TimeUnit.MICROSECONDS.MILLISECONDS));
    }
    @Before
    public void setup(){f= new Future<Integer>();}

}